package org.androidtown.hw3_text_message;
/**
 * 201333493 choi ji young
 * Make a hybrid android app using webview and javascript.
 * By Using html and javascript implements the local html file.
 * The mobile number is updated when you push the buttons.
 * Message - it can accept in html page.
 * submit button - sending the sms messages
 * The result can show the result using toast.
 */

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView browser = (WebView) findViewById(R.id.webView);
        browser.getSettings().setJavaScriptEnabled(true);//It makes the environment to use javascript.
        browser.addJavascriptInterface(new JavaScriptInterface(this), "Android");//it will allow the android app and the html page to 'talk' to each other.
        browser.loadUrl("file:///android_asset/my_webPage.html");
    }

    public class JavaScriptInterface {
        Context mContext;
        String result = "";

        /**
         * Instantiate the interface and set the context
         */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        /**
         * To show the phone number from the web page in the input text.
         */
        @JavascriptInterface
        public String setNum(String num) {
            result += "" + num;
            return result;
        }

        @JavascriptInterface
        public void sendSMS(String smsNumber, String smsText) {
            //When the sender makes the intent who wants to transmit an intent, it delievers this intent to sperate component instead of itself. .
            PendingIntent sentIntent = PendingIntent.getBroadcast(MainActivity.this, 0, new Intent("SMS_SENT_ACTION"), 0);
            PendingIntent deliveredIntent = PendingIntent.getBroadcast(MainActivity.this, 0, new Intent("SMS_DELIVERED_ACTION"), 0);
            /**
             * This method is excuting When the SMS massage has been sent
             */
            if ((smsNumber.length() > 0 && smsNumber.length() <= 11) && smsText.length() > 0) {
                registerReceiver(new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        switch (getResultCode()) {
                            case Activity.RESULT_OK:
                                // Sucess
                                Toast.makeText(mContext, "전송 완료", Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                                // Failure
                                Toast.makeText(mContext, "전송 실패", Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_NO_SERVICE:
                                //No service area
                                Toast.makeText(mContext, "서비스 지역이 아닙니다", Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_RADIO_OFF:
                                // Turning off the radio
                                Toast.makeText(mContext, "무선(Radio)가 꺼져있습니다", Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_NULL_PDU:
                                // Failure of PDU
                                Toast.makeText(mContext, "PDU Null", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    }
                }, new IntentFilter("SMS_SENT_ACTION"));

                SmsManager mSmsManager = SmsManager.getDefault();
                mSmsManager.sendTextMessage(smsNumber, null, smsText, sentIntent, deliveredIntent);
            } else if (smsNumber.contains("*") && smsNumber.contains("#") && smsNumber.length() >= 12) {
                Toast.makeText(mContext, "없는 번호 입니다.", Toast.LENGTH_SHORT).show();
            } else if (smsText.isEmpty() || smsNumber.isEmpty()) {
                Toast.makeText(mContext, "모두 입력해 주세요", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
